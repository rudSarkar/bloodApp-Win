<?php $__env->startSection('content'); ?>
<!-- Reg UI Start Here -->
<div class="page-single">
  <div class="container">
    <div class="row">
      <div class="w-100 mx-2 px-6 my-lg-3 my-3">
        <h3 class="h5 font-weight-normal px-2 py-3 mb-3">
          <span class="text-dark font-weight-bold">Register As Blood Donor</span>
        </h3>

        <form class="mb-3 py-4 px-4 bg-white rounded" method="POST" action="<?php echo e(route('register')); ?>" id="account-form">
        <?php echo csrf_field(); ?>

        <div class="py-1">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label class="form-label" for="email">Email</label>
              <input class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" name="email" value="" placeholder="Hello@world.com" required type="email">

              <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group col-md-6">
              <label class="form-label" for="password">Password</label>
              <input name="password" id="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Your Password" required type="password">

              <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group col-md-12">
              <label class="form-label" for="password-confirm">Confirm Password</label>
              <input name="password_confirmation" id="password-confirm" class="form-control" placeholder="Your Password" required type="password">
            </div>

            <div class="form-group col-md-6">
              <label class="form-label" for="full_name"><?php echo e(__('Name')); ?></label>
              <input id="full_name" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="Full Name" required type="text">

              <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group col-md-6">
              <label class="form-label" for="blood_group">Blood Group</label>
              <select name="blood_group" id="blood_group" class="form-control <?php if ($errors->has('blood_group')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('blood_group'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required>
                <option disabled="" selected="">Blood Group</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
              </select>

              <?php if ($errors->has('blood_group')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('blood_group'); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

            <span class="form-text text-muted">
              <i class="fa fa-exclamation-triangle" style="color: #f00;"></i>
              Carefully select the right blood group
            </span>
          </div>

          <div class="form-group col-md-6">
            <label class="form-label" for="mobile">Mobile Number</label>
            <input name="mobile" id="mobile" class="form-control <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="01712345678" value="" min="1" minlength="8" maxlength="20" required type="number">

            <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

            <span class="form-text text-muted">
              <i class="fa fa-key" style="color: #00c759;"></i>
              We have perfect security to keep safe you from harassment.
            </span>
          </div>

          <div class="form-group col-md-6">
            <label class="form-label" for="address">Division</label>
            <select name="address" class="form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="address" required>
              <option disabled="" selected="">Choose Location</option>
              <option value="Dhaka">
                Dhaka
              </option>
              <option value="Rajshahi">
                Rajshahi
              </option>
              <option value="Rajshahi">
                Rangpur
              </option>
              <option value="Khulna">
                Khulna
              </option>
              <option value="Mymensingh">
                Mymensingh
              </option>
              <option value="Chittagong">
                Chittagong
              </option>
              <option value="Barishal">
                Barishal
              </option>
              <option value="Sylhet">
                Sylhet
              </option>
            </select>

            <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

          </div>
        </div>

        <div class="form-footer mt-3 text-center">
          <p class="small">
            By joining as a blood donor, I am agreeing with our policy
          </p>
          <div class="w-50 mx-auto">
            <button type="submit" class="btn btn-primary btn-block"><?php echo e(__('Register')); ?></button>
          </div>
        </div>
    </div>
  </form>

        <div class="text-center">
          <span class="d-block mb-3">Do you have account?</span>
            <a href="/login" class="btn btn-tertiary">Login To Your Account</a>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Reg UI End here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/BloodApp/resources/views/auth/register.blade.php ENDPATH**/ ?>