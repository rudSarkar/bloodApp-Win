<?php $__env->startSection('content'); ?>
<!-- UI Start from here-->
<div class="page-single">
  <div class="container">
    <div class="row">
      <div class="col col-login mx-auto px-6 my-lg-3">
        <h3 class="h5 font-weight-normal px-2 py-3 mb-3">
          <span class="text-dark font-weight-bold">Login</span>
        </h3>
        <form class="mb-3 py-4 px-4 bg-white rounded" method="POST" action="<?php echo e(route('login')); ?>" id="account-form">
          <?php echo csrf_field(); ?>

          <div class="py-1">
            <div id="form-wrap">
              <div class="form-group">
                <label class="form-label" for="email"><?php echo e(__('E-Mail Address')); ?></label>
                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="hello@world.com" required autocomplete="email" autofocus>

                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

              <div class="form-group">
                <label class="form-label" for="password"><?php echo e(__('Password')); ?>


                  <?php if(Route::has('password.request')): ?>
                    <a class="float-right" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot Your Password?')); ?>

                    </a>
                  <?php endif; ?>
                </label>
                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">

                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

              <div class="form-group">
                <label class="custom-control custom-checkbox">
                    <input class="custom-control-input" data-parsley-multiple="remember_me" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                    <label class="custom-control-label" for="remember">
                        <?php echo e(__('Remember Me')); ?>

                    </label>
                </label>
              </div>

              <div class="form-footer d-flex">
                <button type="submit" class="btn btn-primary btn-block">
                  <?php echo e(__('Login')); ?>

                </button>
              </div>
            </div>
        </div>
      </form>

        <div class="text-center">
          <span class="d-block mb-3">Are you want to donate blood ?</span>
          <a href="/register" class="btn btn-tertiary">Register As Blood Donor</a>
        </div>

      </div>
    </div>
  </div>
</div>
<!--UI End here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/BloodApp/resources/views/auth/login.blade.php ENDPATH**/ ?>