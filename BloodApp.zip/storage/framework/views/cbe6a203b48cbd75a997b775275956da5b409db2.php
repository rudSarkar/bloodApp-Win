<?php $__env->startSection('content'); ?>

      <!-- lists and search -->
				<div class="container">
					<div class="row">
						<div class="col-md-3 mt-5 bg-white border-right p-3">
							<div class="p-2">
		              <span class="text-dark font-weight-bold">Search Donor</span>
									<hr/>
									<div class="py-3">
                    <form action="/" method="POST" role="search" class="ml-3 mb-2">
				              <?php echo e(csrf_field()); ?>

  										<select name="search" class="form-control input-group-responsive">
												<option disabled="" selected="">Search Blood Donor</option>
												<option value="A+">A+</option>
				                <option value="A-">A-</option>
				                <option value="AB+">AB+</option>
				                <option value="AB-">AB-</option>
				                <option value="B+">B+</option>
				                <option value="B-">B-</option>
				                <option value="O+">O+</option>
				                <option value="O-">O-</option>
  										</select>

    									<div class="py-1">
    										<button type="submit" class="btn btn-sm btn-secondary">
													<i class="fa fa-search" aria-hidden="true"></i>
													Search
												</button>
												<a href="/" class="btn btn-sm btn-tertiary">
													<i class="fa fa-refresh" aria-hidden="true"></i>
													Refresh
												</a>
											</div>
                    </form>
									</div>
		          </div>
						</div>

						<div class="col-md-9 mt-5 bg-white p-3">
		          <div class="p-2">
		              <span class="text-dark font-weight-bold">Lists Of Donors</span>
									<hr/>
		          </div>

              <?php if(isset($donors)): ?>

              <?php $__empty_1 = true; $__currentLoopData = $donors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		          <div class="py-3 px-2 my-1 d-block rounded donor-list">
		            <div class="row row-align-items-center">
		                <div class="col-md-9 col-12">
		                    <div class="d-flex align-items-center">

		                        <span class="avatar avatar-lg bg-gray">
		                            <span class="lead"><?php echo e(htmlentities($user->blood_group)); ?></span>
		                        </span>
		                        <div class="avatar-content">
		                            <h5 class="mb-1 text-primary donor-title">
		                                <?php echo e(htmlentities($user->name)); ?>

																</h5>
		                            <span class="d-block text-muted">
																	<i class="fa fa-map-marker" style="color: green;"></i>
																		<span class="text-dark font-weight-bold"><?php echo e(htmlentities($user->address)); ?></span> ,
 																	<i class="fa fa-tint" style="color: red;"></i>
																		<span class="text-dark font-weight-bold">Last Donated: <?php echo e(htmlentities($user->last_donate_date)); ?></span>
																</span>
		                        </div>
		                    </div>
		                </div>
		                <div class="col-md-3 py-2 text-right d-sm-block">
												<?php if(auth()->guard()->guest()): ?>
													<span class="btn btn-sm btn-num phonenumber"><?php echo e(htmlentities($user->mobile)); ?></span>
												<?php else: ?>
													<a href="tel:<?php echo e(htmlentities($user->mobile)); ?>" class="btn btn-sm btn-num phonenumber"><?php echo e(htmlentities($user->mobile)); ?></a>
										    <?php endif; ?>
		                </div>
		            </div>
		          </div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								No Donor Found!
              <?php endif; ?>

              <?php echo e($donors->links()); ?>

				      <?php else: ?>
                  No Donor Found!
              <?php endif; ?>
		        </div>
					</div>
				</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/BloodApp/resources/views/welcome.blade.php ENDPATH**/ ?>