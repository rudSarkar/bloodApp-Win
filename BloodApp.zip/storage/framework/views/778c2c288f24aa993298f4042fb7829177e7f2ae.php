<?php $__env->startSection('content'); ?>
<div class="page-single">
  <div class="container">
    <div class="row">
      <?php if(Auth::check() && Auth::user()->id == 1): ?>
        <div class="w-100 mx-2 px-6 my-lg-3 my-3">
            <h3 class="h5 font-weight-normal px-2 py-3 mb-3">
              <span class="text-dark font-weight-bold">Dashboard</span>
            </h3>

            <div class="mb-3 py-4 px-4 bg-white rounded">
              <?php if(session('status')): ?>
                  <div class="alert alert-success" role="alert">
                      <?php echo e(session('status')); ?>

                  </div>
              <?php endif; ?>

              <?php if(isset($users)): ?>
							<table class="table table-striped table-hover table-responsive">
						        <thead>
						            <tr>
						                <th>ID</th>
						                <th>Name</th>
						                <th>Blood Group</th>
						                <th>Address</th>
                            <th>Email</th>
						                <th>Mobile</th>
						                <th>Last Donate Date</th>
						                <th>Action</th>
						            </tr>
						        </thead>
						        <tbody>
						            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						            <tr>
						                <td>#<?php echo e($user->id); ?></td>
						                <td><?php echo e(htmlentities($user->name)); ?></td>
						                <td><?php echo e(htmlentities($user->blood_group)); ?></td>
						                <td><?php echo e(htmlentities($user->address)); ?></td>
                            <td><?php echo e(htmlentities($user->email)); ?></td>
                            <td><?php echo e(htmlentities($user->mobile)); ?></td>
						                <td><?php echo e(htmlentities($user->last_donate_date)); ?></td>
						                <td>
                              <span class="btn-group">
						                		<a href="dashboard/<?php echo e($user->id); ?>/edit" class="btn btn-secondary mt-2">
						                			<i class="fa fa-fw fa-edit"></i>
						                		</a>
                                <form method="POST" action="<?php echo e(url('dashboard/' . $user->id)); ?>" aria-label="<?php echo e(__('delete')); ?>" class="mt-2">
												          <?php echo csrf_field(); ?>
												          <?php echo method_field('DELETE'); ?>
							                		<button type="submit" onclick="return confirm ('Are you sure you want to delete this User?')" class="btn btn-tertiary ml-2" data-toggle="tooltip" title="Delete">
							                			<i class="fa fa-fw fa-trash"></i>
							                		</button>
						                		</form>
                              </span>
						                </td>
						            </tr>
						            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						        </tbody>
						    </table>
						    <?php endif; ?>

          </div>
        </div>
      <?php elseif(Auth::check() && Auth::user()->isAdmin == 2): ?>
      <div class="w-100 mx-2 px-6 my-lg-3 my-3">
          <h3 class="h5 font-weight-normal px-2 py-3 mb-3">
            <span class="text-dark font-weight-bold">Dashboard</span>
          </h3>

          <div class="mb-3 py-4 px-4 bg-white rounded">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if(isset($users)): ?>
            <table class="table table-striped table-hover table-responsive">
                  <thead>
                      <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Blood Group</th>
                          <th>Address</th>
                          <th>Email</th>
                          <th>Mobile</th>
                          <th>Last Donate Date</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td>#<?php echo e($user->id); ?></td>
                          <td><?php echo e(htmlentities($user->name)); ?></td>
                          <td><?php echo e(htmlentities($user->blood_group)); ?></td>
                          <td><?php echo e(htmlentities($user->address)); ?></td>
                          <td><?php echo e(htmlentities($user->email)); ?></td>
                          <td><?php echo e(htmlentities($user->mobile)); ?></td>
                          <td><?php echo e(htmlentities($user->last_donate_date)); ?></td>
                          <td>
                            <span class="btn-group">
                              <a href="dashboard/<?php echo e($user->id); ?>/edit" class="btn btn-secondary mt-2">
                                <i class="fa fa-fw fa-edit"></i>
                              </a>
                            </span>
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
              <?php endif; ?>

        </div>
      </div>
      <?php else: ?>
        <script>window.location = "/user/edit";</script>
      <?php endif; ?>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/BloodApp/resources/views/dashboard.blade.php ENDPATH**/ ?>