<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Pagination\Paginator;

class SearchController extends Controller
{
    public function searchDonor(Request $request)
    {
    	if ($request->search == "") {
            $donors = User::orderBy('id', 'desc')->paginate(10);
    		    return view('welcome', compact('donors'));
    	}
    	else {
    		$donors = User::where('blood_group', 'LIKE', '%' . $request->search . '%')->paginate(10);
    		$donors->appends($request->only('welcome'));
    		return view('welcome', compact('donors'));
    	}
    }
}
